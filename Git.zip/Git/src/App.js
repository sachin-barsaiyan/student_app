import logo from "./logo.svg";
import "./App.css";
import HomePage from "./Pages/homePage";

function App() {
  return (
    <div>
      {" "}
      <h2 className="heading">Student Data</h2>
      <div className="App">
        <HomePage />
      </div>
    </div>
  );
}

export default App;
