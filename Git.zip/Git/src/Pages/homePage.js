import React from "react";
import { AccordionExampleStyled } from "../Components/accordionComponent";

const HomePage = () => {
  return (
    <>
      <AccordionExampleStyled />
    </>
  );
};

export default HomePage;
