import React from "react";
import { Icon, Label, Menu, Table } from "semantic-ui-react";

const TableExamplePagination = ({maths, chemistry, physics}) => (
  <Table celled>
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell>Subjects</Table.HeaderCell>
        <Table.HeaderCell>Marks</Table.HeaderCell>
      </Table.Row>
    </Table.Header>

    <Table.Body>
      <Table.Row>
        <Table.Cell>Maths </Table.Cell>
        <Table.Cell>{maths}</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>Physics</Table.Cell>
        <Table.Cell>{physics}</Table.Cell>
      </Table.Row>
      <Table.Row>
        <Table.Cell>Chemistry</Table.Cell>
        <Table.Cell>{chemistry}</Table.Cell>
      </Table.Row>
    </Table.Body>
  </Table>
);

export default TableExamplePagination;
