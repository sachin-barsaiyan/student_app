import React, { Component, useState } from "react";
import { Accordion, Icon } from "semantic-ui-react";
import TableExamplePagination from "./tableComponent";

export const AccordionExampleStyled = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [activeMainIndex, setActiveMainIndex] = useState(true);

  const handleClick = (e, titleProps) => {
    const { index } = titleProps;
    const newIndex = activeIndex === index ? -1 : index;
    setActiveIndex(newIndex);
  };

  return (
    <>
      <Accordion styled>
        <Accordion.Title
          active={activeMainIndex}
          //   index={0}
          //   onClick={handleClick}
          onClick={() => {
            setActiveMainIndex(!activeMainIndex);
          }}
        >
          <Icon name="dropdown" />
          Students List
        </Accordion.Title>
        <Accordion.Content active={activeMainIndex}>
          <Accordion styled>
            <Accordion.Title
              active={activeIndex === 0}
              index={0}
              onClick={handleClick}
            >
              <Icon name="dropdown" />
              Student A
            </Accordion.Title>
            <Accordion.Content active={activeIndex === 0}>
              <TableExamplePagination
                physics={"91%"}
                chemistry={"81%"}
                maths={"71%"}
              />
            </Accordion.Content>

            <Accordion.Title
              active={activeIndex === 1}
              index={1}
              onClick={handleClick}
            >
              <Icon name="dropdown" />
              Student B
            </Accordion.Title>
            <Accordion.Content active={activeIndex === 1}>
              <TableExamplePagination
                physics={"82%"}
                chemistry={"75%"}
                maths={"95%"}
              />{" "}
            </Accordion.Content>

            <Accordion.Title
              active={activeIndex === 2}
              index={2}
              onClick={handleClick}
            >
              <Icon name="dropdown" />
              Student C{" "}
            </Accordion.Title>
            <Accordion.Content active={activeIndex === 2}>
              <TableExamplePagination
                physics={"98%"}
                chemistry={"83%"}
                maths={"68%"}
              />
            </Accordion.Content>
          </Accordion>{" "}
        </Accordion.Content>
      </Accordion>
    </>
  );
  //   }
};
